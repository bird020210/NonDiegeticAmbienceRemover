# non-diegetic ambience remover

## what this mod does
removes the creepy and unsettling noises that play when your alone/sanity is low

## specific sounds removed
-DarkAmbience
-DeepBass
-Deeper2
-Didgeridoo1
-Droning2
-FireAlarm
-GhostlySynth
-GhostlySynth2
-Howling
-MessedUpMarimba
-QuietDrum1
-ScreamOutsideShip1
-ScreamOutsideShip2
-ScreamOutsideShip3
-StrangeNoise1
-StrangeNoise1-1
-StrangeNoise2
-StrangeNoise2-1
-StrangeNoise3
-StrangeNoise3-1
-StrangeNoise4
-StrangeNoise4-1
-VoiceCry
-VoiceCry2
-VoiceHey
-Whistle

some sounds may not be removed due to a mistake on my part. i followed a video with the sanity sounds and through testing some of the names weren't accurate to the actual file name counterpart. i did not test all the sounds, but i did (hopefully) fix the ones that were wrong

## issues
incase of issues with the sounds not being replaced or the replaced sound not working, please follow this link to my GitHub repository issues page: https://github.com/bird020210/NonDiegeticAmbienceRemover/issues

## notes
please note that this is my first time uploading a mod to thunderstore, so i hope that this didn't fail terribly lol
